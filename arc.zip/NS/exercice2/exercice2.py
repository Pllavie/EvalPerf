#!/usr/bin/python3.4
# -*-coding:Utf-8 -*
import sys
import getopt
import creationTcl as ct

def main():
    fichier = open("exercice2.tcl","wb")
    ct.initialiseTcl(fichier)
    ct.generate0ToNNoeud(fichier,8)
    ct.createLinkDuplexToCenter(fichier,0,3,6)
    ct.createLinkDuplexToCenter(fichier,3,6,7)
    ct.createLinkDuplex(fichier,6,7)
    windowSize = 64
    for i in range(0,3):
        for j in range(3,6):
            ct.createTcpAgent(fichier,i,j,1,windowSize)
            ct.startTcpFlux(fichier,i,j,0.2,5.0)
    ct.procFinish(fichier,5.0)
    fichier.close()

if __name__ == "__main__":
    main()

"""
    ct.createTcpAgent(fichier,source=0,dest=2,color=1,windowSize=windowSize)
    ct.startTcpFlux(fichier,source=0,dest=2,timerStart=0.2,timerStop=5.0)
    ct.createTcpAgent(fichier,source=0,dest=3,color=2,windowSize=windowSize)
    ct.startTcpFlux(fichier,source=0,dest=3,timerStart=0.2,timerStop=5.0)
    ct.createTcpAgent(fichier,source=1,dest=2,color=3,windowSize=windowSize)
    ct.startTcpFlux(fichier,source=1,dest=2,timerStart=0.2,timerStop=5.0)
    ct.createTcpAgent(fichier,source=1,dest=3,color=4,windowSize=windowSize)
    ct.startTcpFlux(fichier,source=1,dest=3,timerStart=0.2,timerStop=5.0)
"""
